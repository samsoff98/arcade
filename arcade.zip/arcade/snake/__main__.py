from app2 import *



if __name__ == '__main__':
    Mainclass(width=GAME_WIDTH,height=GAME_HEIGHT,fps=60.0).run()
    #Mainclass(width=GAME_WIDTH,height=GAME_HEIGHT,fps=60.0).run()
    #change fps to increase speed 0<fps<60
