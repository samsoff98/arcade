from consts import *
from app import *

if __name__ == '__main__':
    Mainclass(width = GAME_WIDTH, height = GAME_HEIGHT).run()
